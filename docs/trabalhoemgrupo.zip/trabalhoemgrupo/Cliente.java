package POO.trabalhoemgrupo;

import java.util.List;

import java.util.ArrayList;

public class Cliente {
    private String nomeUsuario;
    private List<Serie> listaFutura= new ArrayList<>();
    private List<Serie> listaJaViu= new ArrayList<>();

    public Cliente(String nomeUsuario) {
        this.nomeUsuario = nomeUsuario;
        this.listaFutura = new ArrayList<>();
        this.listaJaViu = new ArrayList<>();
    }

    public void addSerie(Serie serie) {
        listaFutura.add(serie);
    }

    public void retirarSerie(String nomeSerie) {
        listaFutura.remove(nomeSerie);
        listaJaViu.remove(nomeSerie);
    }

    public List<Serie> buscarSeriePorNome(String nome) {
        List<Serie> resultado = new ArrayList<>();
        for (Serie serie : listaFutura) {
            if (serie.nome.equals(nome)) {
                resultado.add(serie);
            }
        }
        for (Serie serie : listaJaViu) {
            if (serie.nome.equals(nome)) {
                resultado.add(serie);
            }
        }
        return resultado;
    }

    public List<Serie> buscarSeriePorGenero(String genero) {
        List<Serie> resultado = new ArrayList<>();
        for (Serie serie : listaFutura) {
            if (serie.genero.equals(genero)) {
                resultado.add(serie);
            }
        }
        for (Serie serie : listaJaViu) {
            if (serie.genero.equals(genero)) {
                resultado.add(serie);
            }
        }
        return resultado;
    }

    public List<Serie> buscarSeriePorIdioma(String idioma) {
        List<Serie> resultado = new ArrayList<>();
        for (Serie serie : listaFutura) {
            if (serie.idioma.equals(idioma)) {
                resultado.add(serie);
            }
        }
        for (Serie serie : listaJaViu) {
            if (serie.idioma.equals(idioma)) {
                resultado.add(serie);
            }
        }
        return resultado;
    }

    public void registrarVisualizacao(Serie serie) {
        serie.registrarVisualizacao();
        listaFutura.remove(serie.nome);
        listaJaViu.add(serie);
    }

    @Override
    public String toString() {
        return "Cliente [nomeUsuario=" + nomeUsuario + ", listaFutura=" + listaFutura + ", listaJaViu=" + listaJaViu
                + "]";
    }
}
