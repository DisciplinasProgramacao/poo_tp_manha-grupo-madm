package POO.trabalhoemgrupo;
import java.io.*;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class aplicativo {
    private List<Serie> listaSistema;
    private String email;
    private String senha;

    public aplicativo() {
        this.listaSistema = new ArrayList<>();
        this.email = "";
        this.senha = "";
    }

    public void cadastrar(String email, String senha) {
        this.email = email;
        this.senha = senha;
    }

    public void logar(String email, String senha) {
        if (this.email.equals(email) && this.senha.equals(senha)) {
            System.out.println("Login efetuado com sucesso!");
        } else {
            System.out.println("Email ou senha incorretos.");
        }
    }

    public void adicionarSerie(Serie serie) {
        listaSistema.add(serie);
    }
    public static List<Cliente> lerEspectadores(String caminhoArquivo) throws IOException {
        List<Cliente> espectadores = new ArrayList<>();
        BufferedReader leitor = new BufferedReader(new FileReader("C:/Users/Diogo/Desktop/vscode/.vscode/POO/trabalhoemgrupo/POO_Espectadores.csv"));
        String linha = leitor.readLine(); // lê a primeira linha (cabeçalho)
        while ((linha = leitor.readLine()) != null) {
            String[] campos = linha.split(";");
            String nome = campos[0];
            String login = campos[1];
            String senha = campos[2];
            espectadores.add(new Cliente());
        }
        leitor.close();
        return espectadores;
    }
    public static List<Serie> lerAudiencia(String caminhoArquivo) throws IOException {
        List<Serie> audiencia = new ArrayList<>();
        BufferedReader leitor = new BufferedReader(new FileReader("C:/Users/Diogo/Desktop/vscode/.vscode/POO/trabalhoemgrupo/POO_Audiencia.csv"));
        String linha = leitor.readLine(); // lê a primeira linha (cabeçalho)
        while ((linha = leitor.readLine()) != null) {
            String[] campos = linha.split(";");
            String login = campos[0];
            char fa = campos[1].charAt(0);
            int idSerie = Integer.parseInt(campos[2]);
            audiencia.add(new Serie(login, fa, idSerie));
        }
        leitor.close();
        return audiencia;
    }
    
    

    // outros métodos para manipular a lista de séries, se necessário
}